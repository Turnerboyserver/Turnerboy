// scripts.js
// Pega aquí toda tu lógica JavaScript: login, Firebase, fetch a endpoints, render, etc.
